function showFox() {
    // your code here...
    console.log('Change image and paragraph to fox...');
    document.getElementById("pic").src="images/fox.jpg";
    document.getElementById("text").innerText = "Fox";
   
}

function showLion() {
    // your code here...
    console.log('Change image and paragraph to lion...');
    document.getElementById("pic").src="images/lion.jpg";
    document.getElementById("text").innerText = "Lion";

}

function showTiger() {
    // your code here...
    console.log('Change image and paragraph to tiger...');
    document.getElementsByName("p").src="images/tiger.png";
    document.getElementById("text").innerText = "Tiger";

}

function showZebra() {
    // your code here...
    console.log('Change image and paragraph to zebra...');
    document.getElementById("pic").src="images/zebra.jpg";
    document.getElementById("text").innerText = "Zebra";

}

